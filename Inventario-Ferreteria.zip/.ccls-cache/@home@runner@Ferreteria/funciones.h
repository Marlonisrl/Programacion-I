void mostrarMenu();
int validarOpcion(int opcion);
void ingresarProducto(char nombre[][50], int cantidad[], float precio[], float precioTotal[], int *numProductos);
void editarProducto(char nombre[][50], int cantidad[], float precio[], float precioTotal[], int numProductos);
void eliminarProducto(char nombre[][50], int cantidad[], float precio[], float precioTotal[], int *numProductos);
void listarProductos(char nombre[][50], int cantidad[], float precio[], float precioTotal[], int numProductos);